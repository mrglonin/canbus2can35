# 2CAN35 CAN Logger Firmware

These are the current experimental CAN-log artifacts for the adapter UID:

```text
37 FF DA 05 42 47 30 38 59 41 22 43
```

They are not the final daily-driver canbox firmware. Use them when the goal is
to capture CAN traffic from the car and then return to the known-good canbox
firmware.

## Files

| File | Size | SHA256 | Use |
|---|---:|---|---|
| `2can35_canlog_v1_usb_update.bin` | 19616 | `81245cc636644c86128b8d0f7d4c17fd4b3c1a44b127f2de7bf55709be8b61dd` | Flash through the normal USB update loader. |
| `2can35_canlog_v1_stlink_full.bin` | 65536 | `d8cbec300e75c264babbc98488e4c75a452ab2b3b37bb2af0d25b8deaa202813` | Full image for ST-Link recovery/programming. |
| `2can35_04350004_canlog_v4_final_mode3_mediafix_usb.bin` | 32176 | `93e197f3e9c1839daa52925cacbe70267552288e5fba2f908941b455946b84c0` | Previous working v04 + mode3 package. It skips selected media fallback states but may still allow spontaneous source/media display paths. |
| `2can35_04350004_canlog_v4_no_auto_media_usb.bin` | 32176 | `339a35e3c46ce7b906bb05046b2a97cc27ebe41edb98a74e46518d8d780864f0` | Historical diagnostic package. It keeps UART and explicit APK/USB display commands, but disables internal mode1 media/source fallback schedulers, which removes useful source/compass behavior. |
| `2can35_04350004_canlog_v4_mode3_original_tbb_no_fallback_usb.bin` | 32176 | `6fc42aa40c26e7009bd327aff1637d56c5707616a6a51de7483e43bf125fcea8` | Historical diagnostic package. It restores source/compass scheduler states and disables selected fallback branches. |
| `2can35_04350006_canlog_v4_mode3_preserve_beeps_usb.bin` | 32176 | `a1caf625e9070be6c9da520336751982238c314b9ac3c90140839c370f4867e6` | Programmer v06 mode1, plus preserved software mode2/mode3 switching and GS USB logger slot. |
| `2can35_04350008_canlog_v4_mode3_preserve_beeps_usb.bin` | 32176 | `846d761cd1e7c26673c40bd9e8193e142b744f9ad2d7ab2a5a152b4d42b6c053` | Current package: programmer v08 mode1, preserved software mode2/mode3 switching and GS USB logger slot. |
| `2can35_04350008_mode3_lab_can_uart_usb.bin` | 32176 | `d17c2fb3fd8ead6d5086260e293eb3e6ddb638db4d7af8c92464fc6248f0c7c6` | Lab package: programmer v08 mode1, stock mode2, custom CDC mode3 with CAN RX/TX plus TEYES/Raise UART RX/TX. |

## Current Three-Mode Package

Use `2can35_04350008_canlog_v4_mode3_preserve_beeps_usb.bin` for current v08
car tests:

- mode1: normal programmer v08 canbox behavior, CDC `/dev/cu.usbmodemKIA1`.
- mode2: stock USB update loader.
- mode3: GS USB CAN logger, VID/PID `1d50:606f`.
- mode1 -> mode3: USB command `0x51` value `0x03`.
- mode3 -> mode1: patched GS USB exit request from the dashboard.
- mode1 -> reset/normal: USB command `0x55` value `0x04`.
- media/BL/parking/TPMS logic: programmer v08 behavior, without the old v04
  media NOP patch.
- direct commands still enabled: FM `0x20`, media/source `0x21`, track `0x22`,
  navigation maneuver `0x45`, ETA/distance `0x47`, nav on/off `0x48`, update
  `0x55`, UID/version `0x56`, settings `0x60`, amp `0x30`.

Use `2can35_04350008_mode3_lab_can_uart_usb.bin` only when mode3 must expose
both CAN and UART. In that build:

- mode1 is still programmer v08 behavior, except the wrapper hooks needed for
  mode switching.
- mode2 is still the stock USB update path.
- mode3 is a custom CDC serial lab app at `0x08009000`, not `gs_usb`.
- mode3 USB appears as serial `KIA CANBOX 2CAN35`, VID/PID `0483:5740`.
- mode3 logs CAN as ASCII lines: `0 t...` for C-CAN and `1 t...` for M-CAN.
- mode3 sends CAN with ASCII commands like `0t1238AABBCCDDEEFF0011`.
- mode3 sends raw UART with ASCII commands like `uFD050540004A`.
- mode3 prints UART RX frames as `U FD...`.
- `mode1` inside mode3 reboots back to the programmer mode1 path.

Rebuild the v08 package from the programmer update and preserved wrapper:

```bash
python3 tools/build_04350008_mode3_package.py
```

Rebuild the v08 + CDC CAN/UART lab mode3 package:

```bash
cd firmware/custom_c
make clean package BUILD=build_mode3_lab TARGET=2can35_mode3_lab \
  APP_BASE=0x08009000 LD_SCRIPT=app_0x08009000.ld \
  ENABLE_CAN_HW=1 USE_STOCK_BEEP=1 ENABLE_REVERSE_OUT=1 \
  ENABLE_TEYES_UART=1 TEYES_UART_BAUD=19200 VERSION_HEX=04353002

cd ../..
python3 tools/build_04350008_mode3_package.py \
  --mode3-app-bin firmware/custom_c/build_mode3_lab/2can35_mode3_lab.bin \
  --out firmware/canlog/2can35_04350008_mode3_lab_can_uart_usb.bin
```

The builder validates the v08 hook bytes before patching. For v08 the two
software-mode hook points are `0x08005478` and `0x08005486`; do not reuse the
older v06 addresses blindly.

The broader `no_auto_media` build is a diagnostic only. It removed too much
useful source switching and default compass behavior in car testing. Current
work should preserve media/source behavior and expand the supported C-CAN/M-CAN
function set.

## Expected USB Logger Protocol

The CDC logger path uses the same serial transport as the normal APK protocol:

```text
port:  /dev/cu.usbmodemKIA1
baud:  19200 8N1
frame: BB dst src len cmd payload... checksum
```

Start logging:

```text
BB 41 A1 07 70 01 CS
```

Stop logging:

```text
BB 41 A1 07 70 00 CS
```

CAN frame from adapter:

```text
BB A1 41 16 70 02 bus flags can_id_le[4] dlc data[8] CS
```

Fields:

- `bus`: adapter CAN channel number.
- `flags bit0`: extended CAN ID.
- `flags bit1`: RTR frame.
- `can_id_le`: little-endian 11-bit or 29-bit CAN ID.
- `dlc`: 0..8.
- `data`: up to 8 bytes, padded in the USB frame.

Capture command:

```bash
python3 ../../tools/stockusb_canlog_2can35.py /dev/cu.usbmodemKIA1 --seconds 120 > ../../logs/live_cdc_canlog_v1.txt
```

## Flash Through USB Loader

From repository root:

```bash
python3 tools/usb_update_2can35.py \
  /dev/cu.usbmodemKIA1 \
  firmware/canlog/2can35_canlog_v1_usb_update.bin
```

If USB disappears after flashing, power-cycle the adapter for 3-5 seconds and
check the port again:

```bash
ls /dev/cu.usbmodem*
```

## Flash Through ST-Link

Use only when USB update is not available or the board needs recovery. Follow:

```text
docs/RECOVERY_STLINK_SEQUENCE.md
```

The short version:

1. Connect SWDIO, SWCLK, GND, VTref/3.3V sense.
2. Use connect-under-reset if readout protection blocks attach.
3. Release reset only when the tool is actually connecting.
4. Program the full image `2can35_canlog_v1_stlink_full.bin`.
5. Power-cycle after a full flash.

## Known Caveats

- This is not the final three-mode firmware.
- It should be used for capture sessions, not for final car integration.
- If it does not raise CDC on Mac after flashing, do not keep reflashing blindly:
  power-cycle, confirm USB enumeration, then recover through ST-Link if needed.
- For two-bus capture the preferred stable path remains the GS USB mode when it
  enumerates as `1d50:606f`; this CDC logger is kept as our own APK-compatible
  logging path.
